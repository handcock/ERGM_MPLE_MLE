coef.ergm <- function(object, ...){object$coef}
coefficients.ergm <- coef.ergm
